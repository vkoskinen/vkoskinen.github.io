declare namespace L {
    export interface PathOptions {
        clickTolerance?: number,
    }
}

declare module 'leaflet-clicktolerance' {
    var e: void;
    export = e;
}